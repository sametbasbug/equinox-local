#!/usr/bin/env node

import os from "node:os";
import path from "node:path";
import { createEquinoxBrowserNativeHostRuntime } from "./equinox-browser-native-host-runtime.js";

const SOCKET_PATH = path.join(
  os.homedir(),
  "Library",
  "Application Support",
  "Equinox Local",
  "equinox-browser.sock",
);
const origin = process.argv[2] || null;

const runtime = createEquinoxBrowserNativeHostRuntime({
  socketPath: SOCKET_PATH,
  origin,
  onFatal: ({ code }) => {
    process.exitCode = code;
  },
});

runtime.start();

process.stdin.on("end", () => process.exit(0));
process.on("SIGTERM", () => {
  runtime.close();
  process.exit(0);
});
