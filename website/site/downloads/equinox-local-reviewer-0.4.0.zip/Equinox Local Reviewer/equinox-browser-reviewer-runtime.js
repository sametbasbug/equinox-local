#!/usr/bin/env node

import http from "node:http";
import { randomBytes } from "node:crypto";
import { pathToFileURL } from "node:url";
import { createEquinoxBrowserBridge } from "./equinox-browser-bridge.js";

export const REVIEWER_HOST = "127.0.0.1";
export const REVIEWER_PORT = 24892;
export const REVIEWER_TEST_URL = "https://local.sametbasbug.dev/reviewer/test/";
export const REVIEWER_SUCCESS_URL = "https://local.sametbasbug.dev/reviewer/test/success/";
const MAX_BODY_BYTES = 16 * 1024;

function json(res, status, value) {
  const body = `${JSON.stringify(value, null, 2)}\n`;
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
  });
  res.end(body);
}

function pageHeaders(contentType) {
  return {
    "Content-Type": contentType,
    "Cache-Control": "no-store",
    "Content-Security-Policy": "default-src 'none'; style-src 'self'; script-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; form-action 'none'; base-uri 'none'",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=(), usb=(), serial=(), hid=()",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
  };
}

function html(csrfToken) {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="equinox-csrf" content="${csrfToken}">
  <title>Equinox Local Reviewer</title>
  <link rel="stylesheet" href="/reviewer.css">
</head>
<body>
  <main class="shell">
    <header><span class="eyebrow">Equinox Browser 0.4.0</span><h1>Equinox Local Reviewer</h1><p>This local-only reviewer runtime uses the same production Native Messaging bridge as Equinox Local. It does not require an account or credentials.</p></header>
    <section class="card"><div><h2>Connection</h2><p id="status-copy">Checking the local bridge…</p></div><span id="status-badge" class="badge">Checking</span></section>
    <section id="consent-note" class="notice" hidden><strong>Browser consent is still required.</strong> Open the Equinox Browser toolbar popup, review the browser-data disclosure, and press <em>Enable browser control</em>. This reviewer page cannot accept consent on your behalf.</section>
    <section class="actions" aria-label="Reviewer actions">
      <button data-action="refresh">Refresh status</button>
      <button data-action="browser_status">Browser status</button>
      <button data-action="tabs_list">List tabs</button>
      <button data-action="open_test">Open public test page</button>
      <button class="primary" data-action="run_smoke">Run browser smoke test</button>
    </section>
    <section class="card output-card"><div class="output-head"><h2>Result</h2><button data-action="clear">Clear</button></div><pre id="output" tabindex="0">Ready.</pre></section>
    <p class="foot">Local endpoint: <code>http://127.0.0.1:24892</code> · Public policy: <a href="https://local.sametbasbug.dev/privacy/" target="_blank" rel="noreferrer">Privacy</a> · Reviewer guide: <a href="https://local.sametbasbug.dev/reviewer/" target="_blank" rel="noreferrer">Guide</a></p>
  </main>
  <script src="/reviewer.js"></script>
</body>
</html>`;
}

const CSS = `:root{color-scheme:light dark;font-family:Inter,ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#0b0e14;color:#edf2ff}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at top,#172038 0,#0b0e14 45%);min-height:100vh}.shell{width:min(920px,calc(100% - 32px));margin:0 auto;padding:54px 0 70px}header{margin-bottom:24px}.eyebrow{font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#95adff;font-weight:800}h1{font-size:clamp(34px,6vw,58px);line-height:1;margin:10px 0 14px}h2{font-size:16px;margin:0 0 6px}p{color:#aeb9d2;line-height:1.6;margin:0}.card,.notice,.actions{border:1px solid #29334a;background:#111722;border-radius:16px;padding:18px;margin-top:14px}.card{display:flex;justify-content:space-between;gap:18px;align-items:center}.badge{border:1px solid #3d4964;border-radius:999px;padding:7px 10px;font-size:12px;font-weight:800}.badge.good{border-color:#277a59;color:#76e2b2}.badge.warn{border-color:#8b6831;color:#ffd483}.notice{color:#f5e2b8;background:#211b12}.notice strong{display:block;margin-bottom:5px}.actions{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px}button{appearance:none;border:1px solid #35415e;border-radius:11px;background:#172033;color:#eef3ff;padding:11px 12px;font:700 13px inherit;cursor:pointer}button:hover{background:#1d2942}button.primary{background:#6f8cff;color:#07102a;border-color:#6f8cff}.output-card{display:block}.output-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}.output-head button{padding:6px 9px;font-size:11px}pre{white-space:pre-wrap;word-break:break-word;background:#090c12;border:1px solid #232b3d;border-radius:12px;padding:14px;min-height:220px;max-height:480px;overflow:auto;color:#dce6ff;font:12px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace}.foot{font-size:12px;margin-top:18px}a{color:#9db3ff}code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace}`;

const JS = `const token=document.querySelector('meta[name="equinox-csrf"]').content;const out=document.querySelector('#output');const copy=document.querySelector('#status-copy');const badge=document.querySelector('#status-badge');const note=document.querySelector('#consent-note');function print(v){out.textContent=typeof v==='string'?v:JSON.stringify(v,null,2);out.focus()}async function status(){try{const r=await fetch('/api/status',{cache:'no-store'});const v=await r.json();const ready=Boolean(v.bridge?.ready);const consent=v.settings?.consentAccepted;badge.textContent=ready?'Connected':'Waiting';badge.className='badge '+(ready?'good':'warn');copy.textContent=ready?'Native Messaging host and Equinox Browser are connected.':'Waiting for Equinox Browser / Native Messaging host.';note.hidden=consent!==false;return v}catch(e){badge.textContent='Error';badge.className='badge warn';copy.textContent=String(e);throw e}}async function action(name){const r=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json','X-Equinox-CSRF':token},body:JSON.stringify({action:name})});const v=await r.json();print(v);await status();return v}document.addEventListener('click',async(e)=>{const b=e.target.closest('button[data-action]');if(!b)return;const a=b.dataset.action;if(a==='clear'){print('Ready.');return}b.disabled=true;try{if(a==='refresh')print(await status());else await action(a)}catch(err){print({ok:false,error:String(err)})}finally{b.disabled=false}});void status();`;

async function readJsonBody(req) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) throw new Error("Request body too large");
    chunks.push(chunk);
  }
  const text = Buffer.concat(chunks).toString("utf8");
  return text ? JSON.parse(text) : {};
}

function publicBridgeSnapshot(snapshot) {
  return {
    active: Boolean(snapshot?.active),
    ready: Boolean(snapshot?.ready),
    expectedExtensionId: snapshot?.expectedExtensionId ?? null,
    extensionVersion: snapshot?.extension?.extensionVersion ?? null,
    connectedAt: snapshot?.connectedAt ?? null,
  };
}

export function createEquinoxBrowserReviewerRuntime({
  host = REVIEWER_HOST,
  port = REVIEWER_PORT,
  bridge = createEquinoxBrowserBridge(),
  csrfToken = randomBytes(24).toString("hex"),
} = {}) {
  let server = null;
  const allowedHosts = new Set([`${host}:${port}`, `localhost:${port}`]);
  const allowedOrigins = new Set([`http://${host}:${port}`, `http://localhost:${port}`]);

  async function bridgeStatus() {
    const snapshot = bridge.snapshot();
    let settings = null;
    if (snapshot.ready) {
      try {
        settings = await bridge.call("settings.status", {}, { timeoutMs: 2_500 });
      } catch (error) {
        settings = { error: error instanceof Error ? error.message : String(error) };
      }
    }
    return { bridge: publicBridgeSnapshot(snapshot), settings };
  }

  async function runSmoke() {
    const before = await bridge.call("status", {});
    if (!before?.consentAccepted || !before?.controlEnabled) {
      throw new Error("Browser control is not enabled. Accept the disclosure in the Equinox Browser popup first.");
    }
    const opened = await bridge.call("open", { url: REVIEWER_TEST_URL });
    const first = await bridge.call("snapshot", { tabId: opened.id, includeReadable: true });
    const link = Array.isArray(first?.elements)
      ? first.elements.find((element) => element?.ref && element?.name === "Continue reviewer test")
      : null;
    if (!link?.ref) throw new Error("Reviewer test link was not found in the browser snapshot.");
    const clicked = await bridge.call("click", { tabId: opened.id, ref: link.ref, agentName: "Reviewer" });
    await new Promise((resolve) => setTimeout(resolve, 450));
    const second = await bridge.call("snapshot", { tabId: opened.id, includeReadable: true });
    const success = Array.isArray(second?.elements)
      && second.elements.some((element) => element?.name === "Reviewer click passed");
    if (!success) throw new Error("The post-click success page was not observed.");
    return {
      passed: true,
      tabId: opened.id,
      openedUrl: opened.url,
      clickedRef: link.ref,
      navigationDetected: Boolean(clicked?.navigation || clicked?.newTabs?.length || second?.tab?.url === REVIEWER_SUCCESS_URL),
      finalUrl: second?.tab?.url ?? null,
    };
  }

  async function executeAction(action) {
    if (action === "browser_status") return await bridge.call("status", {});
    if (action === "tabs_list") return await bridge.call("tabs.list", {});
    if (action === "open_test") return await bridge.call("open", { url: REVIEWER_TEST_URL });
    if (action === "run_smoke") return await runSmoke();
    throw new Error(`Unsupported reviewer action: ${action || "missing"}`);
  }

  async function handler(req, res) {
    try {
      if (!allowedHosts.has(req.headers.host || "")) {
        json(res, 421, { ok: false, error: "Invalid Host header" });
        return;
      }
      const url = new URL(req.url || "/", `http://${req.headers.host}`);
      if (url.search) {
        json(res, 400, { ok: false, error: "Query parameters are not supported" });
        return;
      }
      if (req.method === "OPTIONS") {
        json(res, 405, { ok: false, error: "CORS is not supported" });
        return;
      }
      if (req.method === "GET" && url.pathname === "/") {
        const body = html(csrfToken);
        res.writeHead(200, { ...pageHeaders("text/html; charset=utf-8"), "Content-Length": Buffer.byteLength(body) });
        res.end(body);
        return;
      }
      if (req.method === "GET" && url.pathname === "/reviewer.css") {
        res.writeHead(200, { ...pageHeaders("text/css; charset=utf-8"), "Content-Length": Buffer.byteLength(CSS) });
        res.end(CSS);
        return;
      }
      if (req.method === "GET" && url.pathname === "/reviewer.js") {
        res.writeHead(200, { ...pageHeaders("text/javascript; charset=utf-8"), "Content-Length": Buffer.byteLength(JS) });
        res.end(JS);
        return;
      }
      if (req.method === "GET" && url.pathname === "/api/status") {
        json(res, 200, { ok: true, ...(await bridgeStatus()) });
        return;
      }
      if (req.method === "POST" && url.pathname === "/api/action") {
        if (!allowedOrigins.has(req.headers.origin || "")) {
          json(res, 403, { ok: false, error: "Same-origin request required" });
          return;
        }
        if (req.headers["x-equinox-csrf"] !== csrfToken) {
          json(res, 403, { ok: false, error: "Invalid CSRF token" });
          return;
        }
        if (!String(req.headers["content-type"] || "").toLowerCase().startsWith("application/json")) {
          json(res, 415, { ok: false, error: "application/json required" });
          return;
        }
        const body = await readJsonBody(req);
        const result = await executeAction(body?.action);
        json(res, 200, { ok: true, result });
        return;
      }
      json(res, 404, { ok: false, error: "Not found" });
    } catch (error) {
      json(res, 400, { ok: false, error: error instanceof Error ? error.message : String(error) });
    }
  }

  async function start() {
    if (server) return { host, port, csrfToken };
    await bridge.start();
    server = http.createServer((req, res) => void handler(req, res));
    await new Promise((resolve, reject) => {
      server.once("error", reject);
      server.listen(port, host, resolve);
    });
    return { host, port, csrfToken };
  }

  async function close() {
    if (server) {
      const current = server;
      server = null;
      await new Promise((resolve) => current.close(resolve));
    }
    await bridge.close();
  }

  return Object.freeze({ start, close, bridgeStatus, executeAction, get csrfToken() { return csrfToken; } });
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const runtime = createEquinoxBrowserReviewerRuntime();
  await runtime.start();
  console.error(`Equinox Local Reviewer listening on http://${REVIEWER_HOST}:${REVIEWER_PORT}`);
  const shutdown = async () => {
    await runtime.close().catch(() => {});
    process.exit(0);
  };
  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}
