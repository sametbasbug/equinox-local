#!/bin/bash
set -euo pipefail
umask 077

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "Equinox Local Reviewer uninstall supports macOS only." >&2
  exit 2
fi

HOST_NAME="dev.equinox.browser"
APP_SUPPORT="$HOME/Library/Application Support/Equinox Local"
REVIEWER_DIR="$APP_SUPPORT/Reviewer"
NATIVE_MANIFEST="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts/$HOST_NAME.json"
LAUNCH_AGENT="$HOME/Library/LaunchAgents/dev.equinox.local.reviewer.plist"
HOST_WRAPPER="$REVIEWER_DIR/equinox-browser-native-host"
USER_DOMAIN="gui/$(id -u)"

/bin/launchctl bootout "$USER_DOMAIN" "$LAUNCH_AGENT" >/dev/null 2>&1 || true

if [[ -f "$NATIVE_MANIFEST" && ! -L "$NATIVE_MANIFEST" ]]; then
  if /usr/bin/grep -Fq "\"path\": \"$HOST_WRAPPER\"" "$NATIVE_MANIFEST"; then
    rm -f "$NATIVE_MANIFEST"
  else
    echo "Leaving Native Messaging manifest in place because it is not owned by the reviewer runtime:"
    echo "$NATIVE_MANIFEST"
  fi
fi

rm -f "$LAUNCH_AGENT"
rm -rf "$REVIEWER_DIR"

SOCKET_PATH="$APP_SUPPORT/equinox-browser.sock"
if [[ -S "$SOCKET_PATH" ]]; then
  rm -f "$SOCKET_PATH" 2>/dev/null || true
fi

printf 'Equinox Local Reviewer removed.\n'
