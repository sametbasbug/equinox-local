Equinox Local Reviewer 0.5.2

This package is the macOS reviewer companion for Equinox Browser 0.5.2.
It contains no credentials and does not require access to the private Equinox Local source repository.

Install:
1. Double-click "Install Equinox Local Reviewer.command" or run it from Terminal.
2. The installer downloads the pinned Node.js runtime from nodejs.org over HTTPS and verifies its SHA-256 checksum before use.
3. It registers the Native Messaging host dev.equinox.browser only for the production Equinox Browser extension ID.
4. It starts the loopback-only reviewer UI at http://127.0.0.1:24892/.
5. Install/open the Equinox Browser review package, accept the browser-data disclosure in the extension popup, then run the smoke test from the reviewer UI.

Public reviewer guide:
https://local.sametbasbug.dev/reviewer/

Privacy policy:
https://local.sametbasbug.dev/privacy/
