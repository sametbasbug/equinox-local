#!/bin/bash
set -euo pipefail
umask 077

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "Equinox Local Reviewer currently supports macOS only." >&2
  exit 2
fi

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
PRODUCTION_EXTENSION_ID="npdneefcobilfkjlihghjgjnknenhfoj"
HOST_NAME="dev.equinox.browser"
NODE_VERSION="24.19.0"
REVIEWER_PORT="24892"
APP_SUPPORT="$HOME/Library/Application Support/Equinox Local"
REVIEWER_DIR="$APP_SUPPORT/Reviewer"
NODE_DIR="$REVIEWER_DIR/node"
NATIVE_MANIFEST_DIR="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
NATIVE_MANIFEST="$NATIVE_MANIFEST_DIR/$HOST_NAME.json"
HOST_WRAPPER="$REVIEWER_DIR/equinox-browser-native-host"
LAUNCH_AGENTS="$HOME/Library/LaunchAgents"
LAUNCH_AGENT="$LAUNCH_AGENTS/dev.equinox.local.reviewer.plist"
LOG_DIR="$REVIEWER_DIR/logs"
TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/equinox-local-reviewer.XXXXXX")"
trap 'rm -rf "$TMP_DIR"' EXIT

for file in equinox-browser-reviewer-runtime.js equinox-browser-bridge.js equinox-browser-native-host.js equinox-browser-native-host-runtime.js; do
  if [[ ! -f "$ROOT_DIR/$file" || -L "$ROOT_DIR/$file" ]]; then
    echo "Reviewer package is incomplete or unsafe: $file" >&2
    exit 3
  fi
done

case "$(uname -m)" in
  arm64)
    NODE_ARCHIVE="node-v$NODE_VERSION-darwin-arm64.tar.gz"
    NODE_SHA256="8294b7aa9b03997481c06babf1e8b270c859358f27da57a11509afe537ac381d"
    ;;
  x86_64)
    NODE_ARCHIVE="node-v$NODE_VERSION-darwin-x64.tar.gz"
    NODE_SHA256="d1b5e999db158c62fe8f7267a4476b035d8bd93b1a605bac24a3f0dd166e3316"
    ;;
  *)
    echo "Unsupported Mac architecture: $(uname -m)" >&2
    exit 4
    ;;
esac

NODE_URL="https://nodejs.org/download/release/v$NODE_VERSION/$NODE_ARCHIVE"
NODE_ARCHIVE_PATH="$TMP_DIR/$NODE_ARCHIVE"

echo "Installing Equinox Local Reviewer…"
echo "Downloading pinned Node.js $NODE_VERSION runtime from nodejs.org…"
/usr/bin/curl --fail --location --silent --show-error --proto '=https' --tlsv1.2 "$NODE_URL" -o "$NODE_ARCHIVE_PATH"
ACTUAL_SHA="$(/usr/bin/shasum -a 256 "$NODE_ARCHIVE_PATH" | /usr/bin/awk '{print $1}')"
if [[ "$ACTUAL_SHA" != "$NODE_SHA256" ]]; then
  echo "Node.js download checksum mismatch; installation stopped." >&2
  exit 5
fi

/usr/bin/tar -xzf "$NODE_ARCHIVE_PATH" -C "$TMP_DIR"
EXTRACTED="$TMP_DIR/${NODE_ARCHIVE%.tar.gz}"
if [[ ! -x "$EXTRACTED/bin/node" ]]; then
  echo "Pinned Node.js runtime did not extract correctly." >&2
  exit 6
fi

if [[ -e "$NATIVE_MANIFEST" ]]; then
  EXISTING_PATH="$(/usr/bin/grep -E '^[[:space:]]*"path"[[:space:]]*:' "$NATIVE_MANIFEST" 2>/dev/null | /usr/bin/sed -E 's/^[^:]+:[[:space:]]*"([^"]+)".*/\1/' || true)"
  if [[ -n "$EXISTING_PATH" && "$EXISTING_PATH" != "$HOST_WRAPPER" ]]; then
    echo "A different Equinox Browser Native Messaging host is already installed:" >&2
    echo "$NATIVE_MANIFEST" >&2
    echo "Reviewer install will not overwrite an existing Equinox Local host." >&2
    exit 7
  fi
fi

mkdir -p "$APP_SUPPORT" "$REVIEWER_DIR" "$NODE_DIR" "$NATIVE_MANIFEST_DIR" "$LAUNCH_AGENTS" "$LOG_DIR"
chmod 700 "$APP_SUPPORT" "$REVIEWER_DIR" "$NODE_DIR" "$LOG_DIR" 2>/dev/null || true

rm -rf "$NODE_DIR/current"
mv "$EXTRACTED" "$NODE_DIR/current"
chmod 700 "$NODE_DIR/current/bin/node"

install -m 600 "$ROOT_DIR/src/equinox-browser-reviewer-runtime.js" "$REVIEWER_DIR/equinox-browser-reviewer-runtime.js"
install -m 600 "$ROOT_DIR/src/equinox-browser-bridge.js" "$REVIEWER_DIR/equinox-browser-bridge.js"
install -m 600 "$ROOT_DIR/src/equinox-browser-native-host.js" "$REVIEWER_DIR/equinox-browser-native-host.js"
install -m 600 "$ROOT_DIR/src/equinox-browser-native-host-runtime.js" "$REVIEWER_DIR/equinox-browser-native-host-runtime.js"

NODE_BIN="$NODE_DIR/current/bin/node"
cat > "$HOST_WRAPPER.tmp" <<EOF
#!/bin/bash
exec "$NODE_BIN" "$REVIEWER_DIR/equinox-browser-native-host.js" "\$@"
EOF
chmod 700 "$HOST_WRAPPER.tmp"
mv -f "$HOST_WRAPPER.tmp" "$HOST_WRAPPER"

cat > "$NATIVE_MANIFEST.tmp" <<EOF
{
  "name": "$HOST_NAME",
  "description": "Equinox Browser Native Messaging bridge for Equinox Local Reviewer",
  "path": "$HOST_WRAPPER",
  "type": "stdio",
  "allowed_origins": [
    "chrome-extension://$PRODUCTION_EXTENSION_ID/"
  ]
}
EOF
chmod 600 "$NATIVE_MANIFEST.tmp"
mv -f "$NATIVE_MANIFEST.tmp" "$NATIVE_MANIFEST"

cat > "$LAUNCH_AGENT.tmp" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>dev.equinox.local.reviewer</string>
  <key>ProgramArguments</key><array>
    <string>$NODE_BIN</string>
    <string>$REVIEWER_DIR/equinox-browser-reviewer-runtime.js</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ProcessType</key><string>Interactive</string>
  <key>StandardOutPath</key><string>$LOG_DIR/runtime.log</string>
  <key>StandardErrorPath</key><string>$LOG_DIR/runtime-error.log</string>
</dict></plist>
EOF
chmod 600 "$LAUNCH_AGENT.tmp"
mv -f "$LAUNCH_AGENT.tmp" "$LAUNCH_AGENT"

USER_DOMAIN="gui/$(id -u)"
/bin/launchctl bootout "$USER_DOMAIN" "$LAUNCH_AGENT" >/dev/null 2>&1 || true
if ! /bin/launchctl bootstrap "$USER_DOMAIN" "$LAUNCH_AGENT"; then
  echo "Could not start the reviewer LaunchAgent. See $LOG_DIR/runtime-error.log" >&2
  exit 8
fi
/bin/launchctl kickstart -k "$USER_DOMAIN/dev.equinox.local.reviewer" >/dev/null 2>&1 || true

for _ in {1..30}; do
  if /usr/bin/curl --fail --silent --max-time 1 "http://127.0.0.1:$REVIEWER_PORT/api/status" >/dev/null 2>&1; then
    echo "Equinox Local Reviewer is running."
    echo "Native Messaging host: $NATIVE_MANIFEST"
    echo "Reviewer UI: http://127.0.0.1:$REVIEWER_PORT/"
    /usr/bin/open "http://127.0.0.1:$REVIEWER_PORT/" >/dev/null 2>&1 || true
    exit 0
  fi
  /bin/sleep 0.2
done

echo "Reviewer runtime did not become ready. See $LOG_DIR/runtime-error.log" >&2
exit 9
